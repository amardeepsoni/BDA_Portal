<div id="page-content-wrapper">
  <a href="#menu-toggle" class="menuopener" id="menu-toggle"><i class="fa fa-bars"></i></a>
    <div class="demo-parallax parallax section looking-photo nopadbot" data-stellar-background-ratio="0.5" style="background-image:url('<?php echo base_url();?>schoolassest/upload/demo_02.jpg');">
      <div class="page-title section nobg">
        <div class="container-fluid"> 
          <div class="clearfix">
            <div class="title-area pull-left">
              <h2>Add Student</h2>
            </div>
            <!-- /.pull-right -->
            <div class="pull-right hidden-xs">
              <div class="bread">
                <ol class="breadcrumb">
                  <li><a href="<?php echo base_url();?>schooldashboard/">Home</a></li>
                  <li class="active">Add Student</li>
                </ol>
              </div><!-- end bread --> 
            </div><!-- /.pull-right --> 
          </div><!-- end clearfix --> 
        </div><!-- end container -->
      </div><!-- end page-title --> 
    </div><!-- end parallax -->
</div><!-- end page -->
<div class="section">
  <div class="container-fluid">
      <div align="right">
        <!-- button to add 15 more rows -->
        <button name="add" id="add" class="btn btn-success btn-xs">AddMore</button>
      </div>
      <div class="col-md-12">
        <div class="register-widget clearfix">
          <div class="widget-title">
            <h3>Add Student</h3>
            <hr>
          </div><!-- end title-->
          <input type="hidden" value=" <?php if($this->session->userdata('schoollogged_in')['id']){ ?><?php echo $this->session->userdata('schoollogged_in')['id'];?><?php }?>" name="category_id"/>
          <div class="row">
          <div>
            <table class="table table-dark" id="myTable">
              <!-- thead starts-->
              <thead>
                <tr>
                  <th scope="col">S.N.</th>
                  <th scope="col">Registration no.</th>
                  <th scope="col">First Name</th>
                  <th scope="col">Last Name</th>
                  <th scope="col">Email</th>
                  <th scope="col">Contact</th>
                  <th scope="col">Level</th>
                  <th scope="col">Class</th>
                </tr>
              </thead><!-- thead ends -->
              <!-- tbody starts -->
              <tbody>
                <tr>
                  <td></td>
                  <td></td>
                  <td>
                    <div class="form-group">
                      <!-- Enter First Name -->
                      <input class="form-control first_name" name="firstname" value="<?php if(isset($_POST['firstname'])){ echo $_POST['firstname']; } ?>" type="text" id="firstname" placeholder="Enter First Name">
                    </div>
                  </td>
                  <td>
                    <div class="form-group">
                      <!--Enter Last Name -->
                      <input class="form-control last_name" value="<?php if(isset($_POST['lastname'])){ echo $_POST['lastname']; } ?>" type="text" name="lastname" placeholder="Enter Last Name">
                    </div>
                  </td>
                  <td>
                    <div class="form-group">
                      <!-- Enter email -->
                      <input class="form-control email" contenteditable="true" type="email" name="email" placeholder="Enter Email Address" value="<?php if(isset($_POST['email'])){ echo $_POST['email']; } ?>">
                    </div>
                  </td>
                  <td>
                    <div class="form-group">
                      <!-- Mobile -->
                      <input class="form-control mobile" contenteditable="true" type="number" name="mobile" placeholder="Enter Contact no." value="<?php if(isset($_POST['mobile'])){ echo $_POST['mobile']; } ?>">
                    </div>
                  </td>
                  <td>
                    <div class="form-group" >
                      <!-- Level -->
                      <select class="form-control level" id="level" name="level">
                      <?php if($allschoollavels){ foreach($allschoollavels as $allschoollavel){?>
                        <option value="<?php echo $allschoollavel['id']; ?>"><?php echo $allschoollavel['name']; ?></option>
                      <?php } } ?>
                      </select>
                    </div>
                  </td>
                  <td>
                    <div class="form-group">
                    <!-- Class -->
                    <select class="form-control class" id="class" name="class">
                      <?php if($allschoolclasss){ foreach($allschoolclasss as $allschoolclass){?>
                        <option value="<?php echo $allschoolclass['name']; ?>"><?php echo $allschoolclass['name']; ?></option>
                      <?php } } ?>
                    </select>
                    </div>
                  </td>
                </tr>
              </tbody><!-- tbody ends -->
            </table>
          </div>
          <!-- SaveAll button to save all the rows of data which are completely filled -->
          <div align="center">
            <button type="submit" name="SaveAll" id="SaveAll" class="btn btn-info">SaveALL</button>
          </div>
        </div><!-- end clearfix -->
      </div><!--end col -->
    </div><!-- end row --> 
</div> <!-- end container --> 

<script src="http://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>

$(document).ready(function(){
  // AddMore function 
  $("#add").on('click',function(){
    for($x=0;$x<15;$x++){
      var html_code = '<tr>';
      html_code+= '<td></td>';
      html_code+= '<td></td>';    
      html_code+= '<td><div class="form-group"><input class="form-control first_name" name="firstname" value="<?php if(isset($_POST["firstname"])){ echo $_POST["firstname"]; } ?>" type="text" id="firstname" placeholder="Enter First Name" required></div></td>'                  
      html_code+= '<td><div class="form-group"><input class="form-control last_name" value="<?php if(isset($_POST["lastname"])){ echo $_POST["lastname"]; } ?>" type="text" name="lastname" placeholder="Enter Last Name" required></div></td>'
      html_code+= '<td><div class="form-group"><input class="form-control email" type="email" name="email" placeholder="Enter Email Address" value="<?php if(isset($_POST["email"])){ echo $_POST["email"]; } ?>" required></div></td>'                                 
      html_code+= '<td><div class="form-group"><input class="form-control mobile" type="number" name="mobile" placeholder="Enter Contact no." value="<?php if(isset($_POST["mobile"])){ echo $_POST["mobile"]; } ?>" required></div></td>'                    
      html_code+= '<td><div class="form-group"><select class="form-control level" id="level" name="level"><?php if($allschoollavels){foreach($allschoollavels as $allschoollavel){?><option value="<?php echo $allschoollavel["id"]; ?>"><?php echo $allschoollavel["name"]; ?></option><?php } } ?></select></div></td>'                    
      html_code+= '<td><div class="form-group"><select class="form-control class" id="class" name="class"><?php if($allschoolclasss){foreach($allschoolclasss as $allschoolclass){?><option value="<?php echo $allschoolclass["name"]; ?>"><?php echo $allschoolclass["name"]; ?></option><?php } } ?></select></div></td>'                    
      html_code+= '</tr>'
      $('#myTable').append(html_code); 
      }
  });
  //SaveAll function
  $('#SaveAll').on('click',function(){
    //Intialize empty array for all the inputs feilds
    var firstname = [];
    var lastname = [];
    var email = [];
    var mobile = [];
    var level = [];
    var classs = [];
    // get the first_name class and push the value to firstname array
    $('.first_name').each(function(){
      firstname.push($(this).val());
      });
    // get the last_name class and push the value to lastname array
    $('.last_name').each(function(){
      lastname.push($(this).val());
      });
    // get the email class and push the value to email array
    $('.email').each(function(){
      email.push($(this).val());
      });
    // get the mobile class and push the value to mobile array
    $('.mobile').each(function(){
      mobile.push($(this).val());
      });
    // get the level class and push the value to level array
    $('.level').each(function(){
      level.push($(this).val());
      });
    // get the class class and push the value to class array
    $('.class').each(function(){
      classs.push($(this).val());
      });
    // For loop to check whether all the fields are filled 
    for (i=0;i<firstname.length;i++){
      if (firstname[i] == '' && lastname[i] == '' && email[i] == '' && mobile[i] == ''){
        continue;
        }
      else if (firstname[i] == '' || lastname[i] == '' || email[i] == '' || mobile[i] == ''){
        alert("All fields are required");
        }
    }
    // postData which contains all the data which to send using ajax
    var postData = {
      'firstname': JSON.stringify(firstname),
      'lastname': JSON.stringify(lastname),
      'email': JSON.stringify(email),
      'mobile': JSON.stringify(mobile),
      'level': JSON.stringify(level),
      'classs' : JSON.stringify(classs)
      };
    // ajax request to the server
    $.ajax({
      url:"<?php echo $action; ?>",
      method:"POST",
      data: postData ,
      }).then((data) => {
        if(data)
        alert(data);
        window.location.href= "addstudent";
      }).catch((error) => {
        alert(error);
      });
  });
});


</script>
