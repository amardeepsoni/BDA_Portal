<div class="container body">
  <div class="main_container">
    <?php $this->load->view(adminpath.'/sidebar') ?>
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Dashboard <small>Welcome to admin</small></h3>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="maindashboard">
          <ul class="row"  >
            <li class="col-sm-4 col-lg-3 col-xs-12"><a href="<?php echo base_url(adminpath.'/setting');?>">
              <p><i class="fa fa-edit"></i></p>
              Comman Setting </a> </li>
            <li class="col-sm-4 col-lg-3 col-xs-12"><a href="<?php echo base_url(adminpath.'/loginperson');?>">
              <p><i class="fa fa-edit"></i></p>
              Login User Manager </a> </li>

              
           <!--  <li class="col-sm-4 col-lg-3 col-xs-12"><a href="<?php echo base_url(adminpath.'/headerbanner');?>">
              <p><i class="fa fa-edit"></i></p>
              Header Banner Manager </a> </li>
            <li class="col-sm-4 col-lg-3 col-xs-12"><a href="<?php echo base_url(adminpath.'/page');?>">
              <p><i class="fa fa-edit"></i></p>
              Page Manager </a> </li>
            <li class="col-sm-4 col-lg-3 col-xs-12"><a href="<?php echo base_url(adminpath.'/productimage');?>">
              <p><i class="fa fa-edit"></i></p>
              Page Subcontent Manager </a> </li>
            <li class="col-sm-4 col-lg-3 col-xs-12"><a href="<?php echo base_url(adminpath.'/category');?>">
              <p><i class="fa fa-edit"></i></p>
              Online test  Category Manager </a> </li>
            <li class="col-sm-4 col-lg-3 col-xs-12"><a href="<?php echo base_url(adminpath.'/product');?>">
              <p><i class="fa fa-edit"></i></p>
              Add Test	  Manager </a> </li>
            <li class="col-sm-4 col-lg-3 col-xs-12"><a href="<?php echo base_url(adminpath.'/paddques');?>">
              <p><i class="fa fa-edit"></i></p>
              Add Ques Manager </a> </li>
            <li class="col-sm-4 col-lg-3 col-xs-12"><a href="<?php echo base_url(adminpath.'/photo');?>">
              <p><i class="fa fa-edit"></i></p>
              Gallery  Manager </a> </li>
            <li class="col-sm-4 col-lg-3 col-xs-12"><a href="<?php echo base_url(adminpath.'/clients');?>">
              <p><i class="fa fa-edit"></i></p>
              Clients Manager </a> </li>
            
            <li class="col-sm-4 col-lg-3 col-xs-12"><a href="<?php echo base_url(adminpath.'/news');?>"><p><i class="fa fa-edit"></i></p> news Manager </a> </li>
            
            <li class="col-sm-4 col-lg-3 col-xs-12"><a href="<?php echo base_url(adminpath.'/testimonials');?>">
              <p><i class="fa fa-edit"></i></p>
              Client Testimonial Manager </a> </li>
            <li class="col-sm-4 col-lg-3 col-xs-12"><a href="<?php echo base_url(adminpath.'/blogcat');?>">
              <p><i class="fa fa-edit"></i></p>
              BLog Category </a> </li>
            <li class="col-sm-4 col-lg-3 col-xs-12"><a href="<?php echo base_url(adminpath.'/blogscon');?>">
              <p>
              <p><i class="fa fa-edit"></i></p>
              </p>
              Blogs Manager </a> </li> -->
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
