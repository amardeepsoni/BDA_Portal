<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from psdconverthtml.com/live/edupress/index-02.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 16 Oct 2018 18:29:46 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title><?php echo $page_title; ?></title>
<meta name="description" content="">
<meta name="author" content="">
<meta name="keywords" content="">
<link href="<?php echo base_url();?>css/reset.css" rel="stylesheet">
<!-- Custom Fonts -->
<link href="<?php echo base_url();?>css/fonts.css" rel="stylesheet">
<link href="<?php echo base_url();?>css/animate.css" rel="stylesheet">
<!-- Bootstrap -->
<link href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!-- Select2 -->
<link href="<?php echo base_url();?>assets/select2/css/select2.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo base_url();?>assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<!-- Magnific Popup -->
<link href="<?php echo base_url();?>assets/magnific-popup/css/magnific-popup.css" rel="stylesheet">
<!-- Iconmoon -->
<link href="<?php echo base_url();?>assets/iconmoon/css/iconmoon.css" rel="stylesheet">
<!-- Owl Carousel -->
<link href="<?php echo base_url();?>assets/owl-carousel/css/owl.carousel.min.css" rel="stylesheet">
<!-- Animate -->
<link href="<?php echo base_url();?>css/animate.css" rel="stylesheet">
<!-- Custom Style -->
<link href="<?php echo base_url();?>css/custom.css" rel="stylesheet">
<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
        <script src="js/html5shiv.min.js"></script>
        <script src="js/respond.min.js"></script>
        <![endif]-->

</head>
<body>

<!-- Start Preloader -->
<div id="loading">
  <div class="element">
    <div class="sk-folding-cube">
      <div class="sk-cube1 sk-cube"></div>
      <div class="sk-cube2 sk-cube"></div>
      <div class="sk-cube4 sk-cube"></div>
      <div class="sk-cube3 sk-cube"></div>
    </div>
  </div>
</div>
<!-- End Preloader --> 

<!-- Start Header -->
<header> 
  <!-- Start Header top Bar -->
  <div class="header-top">
    <div class="container clearfix">
      <ul class="follow-us hidden-xs">
        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
        <li><a href="#"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
        <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
        <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
      </ul>
      <div class="right-block clearfix">
        <ul class="top-nav hidden-xs">
          <li><a href="#">Register</a></li>
          <li><a href="#">Apply Online</a></li>
          <li><a href="#">Blog</a></li>
          <li><a href="#">FAQs</a></li>
        </ul>
        <div class="lang-wrapper">
          <div class="select-lang">
            <select id="currency_select">
              <option value="usd">USD</option>
              <option value="aud">AUD</option>
              <option value="gbp">GBP</option>
            </select>
          </div>
          <div class="select-lang2">
            <select class="custom_select">
              <option value="en">English</option>
              <option value="fr">French</option>
              <option value="de">German</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- End Header top Bar --> 
  <!-- Start Header Middle -->
  <div class="container header-middle">
    <div class="row"> <span class="col-xs-6 col-sm-3"><a href="<?php echo base_url(''); ?>"><img  src="<?php echo base_url();?>images/logo-new.png" class="img-responsive" alt=""></a></span>
      <div class="col-xs-6 col-sm-3"></div>
      <div class="col-xs-6 col-sm-9">
        <div class="contact clearfix">
          <ul class="hidden-xs">
            <li> <span>Email</span> <a href="#">info@intellify.in</a> </li>
            <li> <span>Call Us</span> +91 9891193363 </li>
          </ul>
          <?php
             if($this->session->userdata('schoollogged_in')['id']){ ?>
          <a href="<?php echo base_url('schoolaccount'); ?>" class="login">My Account <span><i class="fa fa-trophy"></i></span></a> <a  href="<?php echo base_url('schoollogin/schoollogout'); ?>" class="login">Logout <span><i class="fa fa-trophy"></i></span></a>
          <?php } else {?>
          <a  href="<?php echo base_url('schoollogin'); ?>"class="login">School Login <span class="icon-more-icon"></span></a>
          <?php } ?>
          <?php
             if($this->session->userdata('studentlogged_in')['id']){ ?>
          <a href="<?php echo base_url('myaccount'); ?>" class="login">My Account <span><i class="fa fa-trophy"></i></span></a> <a  href="<?php echo base_url('login/logout'); ?>" class="login">Logout <span><i class="fa fa-trophy"></i></span></a>
          <?php } else {?>
          <a  href="<?php echo base_url('login'); ?>"class="login">Student Login <span class="icon-more-icon"></span></a>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>
  <!-- End Header Middle --> 
  <!-- Start Navigation -->
  <nav class="navbar navbar-inverse">
    <div class="container">
      <div class="navbar-header">
        <button aria-controls="navbar" aria-expanded="false" data-target="#navbar" data-toggle="collapse" class="navbar-toggle collapsed" type="button"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      </div>
      <div class="navbar-collapse collapse" id="navbar">
        <form class="navbar-form navbar-right">
          <input type="text" placeholder="Search Now" class="form-control">
          <button class="search-btn"><span class="icon-search-icon"></span></button>
        </form>
        <ul class="nav navbar-nav">
          <li> <a href="<?php echo base_url(''); ?>">Home</a></li>
          <li> <a href="<?php echo base_url('about-us'); ?>">Who We Are</a></li>
          <li class="dropdown"> <a data-toggle="dropdown" href="#">ISCO <i class="fa fa-angle-down" aria-hidden="true"></i></a>
            <ul class="dropdown-menu">            
              <?php echo categorytopmenu(0); ?>
            </ul>
          </li>
          <li> <a href="<?php echo base_url('projects'); ?>">Projects</a></li>  
          <li> <a href="<?php echo base_url();?>contactus">Contact</a></li>
        </ul>
      </div>
    </div>
  </nav>
</header>


<!---

<div id="wrapper">




<header class="header normal-header  <?php  if ($this->uri->segment(1)) { echo "default-header"; } ?>" data-spy="affix" data-offset-top="197">
  <div class="container">
    <nav class="navbar navbar-default yamm">
      <div class="container-full">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
          <a class="navbar-brand with-text"  href="<?php echo base_url();?>">UTSAAH</a> </div>
      
        
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="dropdown yamm-fw"><a href="<?php echo base_url();?>" >Home </a> </li>
            <li><a title="" href="<?php echo base_url('about-us'); ?>">About</a></li>
            <li class="dropdown normal-menu has-submenu"> <a href="#">Courses <span class="fa fa-angle-down"></span></a>
              <ul class="dropdown-menu">
                <?php echo categorytopmenu(0); ?>
              </ul>
            </li>
            <li><a title="" href="#">Contact</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li class="dropdown cartmenu searchmenu hasmenu"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-search"></i></a>
              <ul class="dropdown-menu start-right">
                <li>
                  <div id="custom-search-input">
                    <div class="input-group">
                      <input type="text" class="form-control input-lg" placeholder="Search here..." />
                      <span class="input-group-btn">
                      <button class="btn btn-primary btn-lg" type="button"> <i class="fa fa-search"></i> </button>
                      </span> </div>
                  </div>
                </li>
              </ul>
            </li>
           
          </ul>---> 
