<div id="page-content-wrapper"> <a href="#menu-toggle" class="menuopener" id="menu-toggle"><i class="fa fa-bars"></i></a>
  <div class="demo-parallax parallax section looking-photo nopadbot" data-stellar-background-ratio="0.5" style="background-image:url('<?php echo base_url();?>schoolassest/upload/demo_02.jpg');">
    <div class="page-title section nobg">
      <div class="container-fluid">
        <div class="clearfix">
          <div class="title-area pull-left">
            <h2>School account</h2>
          </div>
          <!-- /.pull-right -->
          <div class="pull-right hidden-xs">
            <div class="bread">
              <ol class="breadcrumb">
                <li><a href="<?php echo base_url();?>schoolaccount">Home</a></li>
                <li class="active">School account</li>
              </ol>
            </div>
            <!-- end bread --> 
          </div>
          <!-- /.pull-right --> 
        </div>
        <!-- end clearfix --> 
      </div>
    </div>
    <!-- end page-title --> 
  </div>
  <div class="section">
    <div class="container-fluid">
      <!-- Notify user for any Error -->
      <?php if ($this->session->flashdata('schoolloginnotify')) { ?>
      <div class="alert alert-danger">
        <?= $this->session->flashdata('schoolloginnotify') ?>
      </div>
      <?php } ?>
      <!-- Details of the schools from the schoolinfo varaible -->
      <h3><strong>Welcome to </strong><?php echo $schoolinfo->name; ?>. </h3>
      <div class="cnt-block">
        <div class="row">
          <div class="col-lg-6">
            <p>
              <label><b>Contact Person:</b></label>
              <!-- Contact Person -->
              <?php echo $schoolinfo->conperson; ?></p>
            <p>
              <label><b>Email:</b></label>
              <!-- Email -->
              <?php echo $schoolinfo->email; ?> </p>
            <p>
              <label><b>Mobile:</b></label>
              <!-- Mobile -->
              <?php echo $schoolinfo->mobile; ?> </p>
            <p>
              <label><b>Mobile1:</b></label>
              <!-- Mobile1 -->
              <?php echo $schoolinfo->mobile1; ?></p>
            <p>
              <label><b>Who:</b></label>
              <!-- who intern-->
              <?php echo $schoolinfo->who; ?></p>
              <?php if($schoolinfo->intern){?>
            <p>
              <label><b>intern_id:</b></label>
              <!-- intern_id -->
              <?php echo $schoolinfo->intern; ?></p>
            <?php }?>
          </div>
          <div class="col-lg-6">
            <label><b>Address:</b></label>
            <br>
            <!-- Address -->
            <?php echo $schoolinfo->address; ?> </div>
        </div>
      </div>
      <div class="row"></div>
    </div>
    <br />

    
  </div>
</div>