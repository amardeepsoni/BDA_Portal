<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        
    } 

	public function index()
	{
		$data=array();
		if($this->session->userdata('studentlogged_in')['id']){ 
			redirect('myaccount');
		}
		$this->load->model('model_category');


		$data['allcategorys']= array();	



    	$results = $this->model_category->getcategories();

		if ($results) {  

			foreach($results as $val){

				$fildata = array(
					'filter_pid' => $val->id

				);

				$data['allcategorys'][] = array(

					'id' => $val->id,

					'name' => $val->name,

					'status' => $val->status

				);

			}

		}


    	$data['page_title'] = 'Register';
    	$data['title'] = 'Register';

		$data['action'] = base_url().'register/add';

    	$this->load->view('accountstudentheader',$data);
    	$this->load->view('register',$data);
    	$this->load->view('accountfooter');
	}

	public function add() {
		$json = array();

		 if ($this->input->server('REQUEST_METHOD') == 'POST') {
				$this->load->model('student_model');
				$checkaccount=$this->student_model->read_by_email($this->input->post('email'));
				if($checkaccount){
					$json['error']="This email already in our database.";
				}
				else{
					$data['student'] = (object)$postData = [
					'firstname'    => $this->input->post('firstname'),
					'lastname'    => $this->input->post('lastname'),
					'category_id' 	   => $this->input->post('category_id'),
					'email' 	   => $this->input->post('email'),
					'mobile' 	   => $this->input->post('mobile'),
					'password' 	   => md5($this->input->post('password')),
					'mpassword' 	   => $this->input->post('password'),
					'date_added'  => date('Y-m-d'),
					]; 
					$this->student_model->create($postData);
					$json['success']="You have been successfully registered.";
				}
			}

		echo json_encode($json);
    }	

    public function randStrGen($mode = null, $len = null){
        $result = "";
        if($mode == 1):
            $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        elseif($mode == 2):
            $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        elseif($mode == 3):
            $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
        elseif($mode == 4):
            $chars = "0123456789";
        endif;

        $charArray = str_split($chars);
        for($i = 0; $i < $len; $i++) {
                $randItem = array_rand($charArray);
                $result .="".$charArray[$randItem];
        }
        return $result;
    }

}	
