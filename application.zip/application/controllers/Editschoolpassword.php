<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Editschoolpassword extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model(array('school_model'));  
    } 
    public function index($id = null){ 
        // Redirect user if not logged in 
        if(!$this->session->userdata('schoollogged_in')['id']){ 
            redirect('schoollogin');
        }
        $data=array();
        $data['page_title'] = 'Edit Password';
        $data['meta_keyword'] = 'Edit Password';
        $data['meta_description'] = 'Edit Password';
        $data['breadcrumbs'][] = array(
        'text' => 'Home',
        'href' => base_url()
        );
        // schoolinfo array contains all the details of the school
        $data['schoolinfo'] = $this->school_model->schoolinfo(($this->session->userdata('schoollogged_in')['email']));
        //action when a update button is pressed
        $data['action'] = base_url('editschoolpassword/update');
        //Loading the views
        $this->load->view('accountheader',$data);
        $this->load->view('editschoolpassword',$data);
        $this->load->view('accountfooter');
    } 
    public function update(){
        //Updated password
        $data['testimonial'] = (object)$postData = [
            'category_id'      => $this->input->post('id',true),
            'password'    => md5($this->input->post('password',true)),
            'mpassword'    => $this->input->post('password',true),
        ]; 

        //Update password success
        if ($this->school_model->passwordupdate($postData)) {
            #set success message
            $this->session->set_flashdata('editschoolpassword','Change Successfully');
        }
        else {
            #set exception message
            $this->session->set_flashdata('editschoolpassword', display('please_try_again'));
        }
        // schoolinfo array contains all the updated details of the school
        $data['schoolinfo'] = $this->school_model->schoolinfo(($this->session->userdata('schoollogged_in')['email']));
        redirect('editschoolpassword');
    }



}

