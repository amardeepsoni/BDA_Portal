<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Addstudent extends CI_Controller {
	public function __construct(){
        parent::__construct();
    } 
	public function index(){
		
		$data=array();
		// Redirect user if not logged in 
		if(!$this->session->userdata('schoollogged_in')['id']){ 
			redirect('schoollogin');
		}
    	$data['page_title'] = 'Add Student';
		$data['title'] = 'Add Student';
		//Action to add the studnets to the database 
		$data['action'] = base_url().'addstudent/add';
		//Load the model_schoollavel model

		$this->load->model('model_schoollavel');
		// Fetching all the levels from the model_schoollavel
		$data['allschoollavels']= array();	
		$results = $this->model_schoollavel->getschoollavels();
		if ($results) {  
			foreach($results as $val){
				$data['allschoollavels'][] = array(
					'id' => $val->id,
					'name' => $val->name,
				);
			}
		}
		// Fetching all the classs from the model_schoollavel
		$data['allschoolclasss']= array();	
		$results = $this->model_schoollavel->getschoolclass();
		if ($results) {  
			foreach($results as $val){
				$data['allschoolclasss'][] = array(
					'id' => $val->id,
					'name' => $val->name,
				);
			}
		}
		// Load the views
    	$this->load->view('accountheader',$data);
    	$this->load->view('addstudent',$data);
    	$this->load->view('accountfooter');
	}
	//Function to add the students
	public function add() {
		// Empty json array
		$json = array();
		// decode all the input data
		$first_name=json_decode($this->input->post('firstname'));
		$last_name=json_decode($this->input->post('lastname'));
		$email=json_decode($this->input->post('email'));
		$mobile=json_decode($this->input->post('mobile'));
		$level=json_decode($this->input->post('level'));
		$class=json_decode($this->input->post('classs'));
		// For loop to insert all the rows into database
		for($count = 0; $count<count($first_name); $count++)
  		{
			$first_name_clean = $first_name[$count];
			$last_name_clean = $last_name[$count];
			$email_clean = $email[$count];
			$mobile_clean = $mobile[$count];
			$level_clean = $level[$count];
			$class_clean = $class[$count];
			// Check if all the fields are filled 
			if($first_name_clean != '' && $last_name_clean != '' && $email_clean != '' && $mobile_clean != '' && $level_clean != '' && $class_clean != '')
			{
					if ($this->input->server('REQUEST_METHOD') == 'POST') {
						// Load the model 
						$this->load->model('student_model');
						$checkaccount=$this->student_model->read_by_email($email_clean);
						// Check if the students already exists or not
						if($checkaccount){
							//Set the message
							$json['error']="This email already in our database.";
						}
						else{
							// Read the category_id of the school
							$category_id = $this->session->userdata('schoollogged_in')['id'];
							$this->load->model('school_model');
							// Read the recount of the school
							$res = $this->school_model->read_regcount($category_id);
							$regcount = $res->regcount;
							//Logic to generate the registrationno for the students
							if (strlen((string)$category_id) == 1) $id = '00' . $category_id;
							else if (strlen((string)$category_id) == 2) $id = '0' . $category_id;
							else $id = $category_id;
							$regcount++;
							if (strlen((string)$regcount) == 1) $reg_count = '00' . $regcount;
							else if (strlen((string)$regcount) == 2) $reg_count = '0' . $regcount;
							else $reg_count=$regcount;
							$reg_no = '6' . $id . $reg_count;	
							$password = md5($reg_no);
							$data['regcount'] = $regcount;
							$data['category_id'] = $category_id;
							$data['student'] = (object)$postData = [
							'firstname'    => $first_name_clean,
							'lastname'    => $last_name_clean,
							'registrationno' => $reg_no,
							'category_id' 	   => $this->session->userdata('schoollogged_in')['id'],
							'class' => $class_clean,
							'level' => $level_clean,
							'email' 	   => $email_clean,
							'mobile' 	   => $mobile_clean,
							'username'     => $reg_no,
							'password' 	   => $password,
							'mpassword'     => $reg_no,
							'date_added'  => date('Y-m-d'),
							];
							//Add the data to the database 
							if ($this->student_model->create($postData)){
								// update the reg_count of the school
								$this->load->model('school_model');
								$this->school_model->updatereg_count($data);
								//Set the message after sucess
								$json['success']="You have been successfully added student.";
							}
						}
					}
				}
			}
		if ($json)	
		echo json_encode($json);
    }
}	
