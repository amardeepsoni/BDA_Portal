<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Studymaterials extends CI_Controller {
	public function index(){
		// Redirect user if not logged in 
		if(!$this->session->userdata('schoollogged_in')['id']){ 
			redirect('schoollogin');
		}
		// Load the views
        $this->load->model('model_studymaterials');
        $this->load->model('model_page');
		$data=array();
		$data['page_title']="Study Materials ";
		$data['meta_keyword']="Study Materials";
		$data['meta_description']="Study Materials";
		$data['heading']="Study Materials";
		$data['breadcrumbs'][] = array(
		'text' => 'Home',
		'href' => base_url().'schoolaccount'
		);
		$data['breadcrumbs'][] = array(
		'text' => 'Study Materials',
		'href' => base_url().'studymaterials'
		);
		$data['catproducts']=array();
		$catresults = $this->model_studymaterials->getallcategoriess(0);
		if ($catresults) {
			foreach($catresults as $catval){
				$products= array();	
				$results = $this->model_studymaterials->getproductcategory($catval->id);
				if ($results) {
					foreach($results as $val){
						$products[] = array(
							'id' => $val->id,
							'name' => $val->name,
                            'image' => base_url()."uploads/".$val->image,
							'home' => $val->home
						);
					}
				}
				$data['catproducts'][] = array(
					'id' => $catval->id,
					'name' => $catval->name,
					'products' => $products
				);
			}
		}
		//Load the views
		$this->load->view('accountheader',$data);
		$this->load->view('studymaterials',$data);
		$this->load->view('accountfooter');
	}
}



