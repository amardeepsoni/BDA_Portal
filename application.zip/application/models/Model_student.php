<?php

class Model_student extends CI_Model {

	

public function getstudents() {

		$this->db->select('*');

		$this->db->from('student');

		$query = $this->db->get();

        $this->db->order_by("ordernum","asc");
		return $query->result();

	}
	public function user_delete($id){

		$this->db->where('registrationno', $id);
		$this->db->delete('student');
  }
  public function deleteall($id){

	$this->db->where('category_id', $id);
	$this->db->delete('student');
}

}

?>