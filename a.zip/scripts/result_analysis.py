#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from collections import OrderedDict
import pymysql.cursors
import sys
import os


# In[2]:


class result(object):
    
    def __init__(self, file_name):
        self.file_name = file_name
    
    # function to get dataset of results
    def get_data(self):

        mydir = os.getcwd()
        os.chdir("..")
        path = os.getcwd() + '/Intellify/uploads/csv/'
        data_csv = pd.read_csv(path + self.file_name)
        os.chdir(mydir)
        return data_csv
    
    # get total number of skills
    def get_skills(self):

        return 5
    
    # alloting index for each question
    def get_question_index(self):

        return 1, 45

    # get number of difficulty levels
    def get_difficulty_levels(self):

        return 5

    # get details for student responses in exam
    def get_student_responses(self, data_csv):

        questionStartIndex, questionEndIndex = self.get_question_index()
        q_cols = ['Points' + str(i) for i in range(questionStartIndex,questionEndIndex+1)]
        answerCols=data_csv[q_cols]
        numStudents=answerCols.shape[0]

        return q_cols, answerCols, numStudents
    
    def manipulate_dataset(self, data_csv):

        # get total number of questions
        questionStartIndex, questionEndIndex = self.get_question_index()
        numQuestions=(questionEndIndex-questionStartIndex+1)

        questionsInEachDifficultyLevel=(questionEndIndex-questionStartIndex+1)/self.get_difficulty_levels()

        q_cols, answerCols, numStudents = self.get_student_responses(data_csv)

        # get question labels in  transposed form
        transposed_df=answerCols.transpose()

        # calculating number of correct responses for each questions
        transposed_df['numCorrect']=transposed_df.astype(bool).sum(axis=1)

        # make qid feature ranging from first question till last question
        transposed_df['qid'] = range(questionStartIndex, questionStartIndex+len(transposed_df))

        # compute percentage of correct answer given
        transposed_df['correctPercentage']=transposed_df['numCorrect']*100.0/numStudents

        # skill type=0 is to skip header
        transposed_df['skillType']=0

        # assign skill type wrt question id
        transposed_df.loc[(transposed_df['qid']>=1)&(transposed_df['qid']<=10),'skillType' ]=1
        transposed_df.loc[(transposed_df['qid']>=11)&(transposed_df['qid']<=20),'skillType' ]=2
        transposed_df.loc[(transposed_df['qid']>=21)&(transposed_df['qid']<=30),'skillType' ]=3
        transposed_df.loc[(transposed_df['qid']>=31)&(transposed_df['qid']<=40),'skillType' ]=4
        transposed_df.loc[(transposed_df['qid']>=41)&(transposed_df['qid']<=45),'skillType' ]=5


        colsReqd=['numCorrect','qid','correctPercentage','skillType']
        reqdDf=transposed_df[colsReqd].sort_values('correctPercentage',ascending=False)
        reqdDf['difficulty_level']=0
        
        for i in range(1,int(self.get_difficulty_levels()+1)):
            reqdDf.iloc[int((i-1)*questionsInEachDifficultyLevel):int((i)*questionsInEachDifficultyLevel),-1]=i

        question_wise_accuracy = reqdDf['correctPercentage'].to_dict()
        
        return question_wise_accuracy
    
    def get_results(self, data_csv):

        student_id_array = data_csv['StudentID'].values

        q_cols, answerCols, numStudents = self.get_student_responses(data_csv)
        response_array = answerCols.values
        
        dict_correct_responses={}
        dict_wrong_responses={}
        dict_skill_correct={}
        dict_skill_incorrect={}

        for skillType in range(1, self.get_skills() + 1):
            dict_skill_correct[skillType]={}
            dict_skill_incorrect[skillType]={}

        skillWiseScore={}

        # curr_student_id = 5020005
        # curr_responses = response_array[numpy.where(student_id_array == curr_student_id)[0][0]]
        dict_correct_responses = {}
        dict_incorrect_responses = {}
        dict_skill_wise_scores = {}
        dict_total_scores = {}

        for stud in range(numStudents):    
            curr_student_id = student_id_array[stud]
            curr_responses = response_array[stud]

            # print(curr_responses)
            curr_df = pd.DataFrame(columns=['response'])
            curr_df['response'] = curr_responses

            correct_answers = {'correct_responses':[]}
            incorrect_answers = {'incorrect_responses':[]}

            response = curr_df['response'].to_dict()
            for i in response.keys():
                if response[i]:
                    correct_answers['correct_responses'].append(i+1)
                else:
                    incorrect_answers['incorrect_responses'].append(i+1)

            dict_correct_responses[curr_student_id] = correct_answers
            dict_incorrect_responses[curr_student_id] = incorrect_answers

            skill_1 = skill_2 = skill_3 = skill_4 = skill_5 = 0
            for i in correct_answers['correct_responses']:
                if i in range(1,11):
                    skill_1 += 1
                elif i in range(11, 21):
                    skill_2 += 1
                elif i in range(21, 31):
                    skill_3 += 1
                elif i in range(31, 41):
                    skill_4 += 1
                else:
                    skill_5 += 1

            skill_wise_score = {}
            skill_wise_score['skill_1'] = skill_1*4
            skill_wise_score['skill_2'] = skill_2*4
            skill_wise_score['skill_3'] = skill_3*4
            skill_wise_score['skill_4'] = skill_4*4
            skill_wise_score['skill_5'] = skill_5*4

            dict_skill_wise_scores[curr_student_id] = skill_wise_score
            dict_total_scores[curr_student_id] = sum(skill_wise_score.values())

        ranks_skill_wise = {}    
        for i in range(1, 6):
            ranks_skill_wise['skill_'+str(i)] = sorted(dict_skill_wise_scores, key=lambda x: (dict_skill_wise_scores[x]['skill_'+str(i)]))

        od = OrderedDict(sorted(dict_total_scores.items(), key=lambda kv:kv[1], reverse=True))

        return dict_correct_responses, dict_incorrect_responses, dict_skill_wise_scores, ranks_skill_wise, od


# In[3]:


s1 = result('omr_output.csv')
data_csv = s1.get_data()
question_acc = s1.manipulate_dataset(data_csv)
dict_correct_responses, dict_incorrect_responses, dict_skill_wise_scores, ranks_skill_wise, od = s1.get_results(data_csv)


# In[4]:


#question_acc


# In[15]:


# Connect to the database
connection = pymysql.connect(host='localhost',
                             user='root',
                             password='',
                             db='quizdb',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

try:

    with connection.cursor() as cursor:
        
        i = 0
        for student_id in data_csv['StudentID']:
            school_id = int(str(student_id)[:4])
            level = data_csv['QuizName'][i][:7].split()[-1]
            i += 1
            
            # get quizid corresponding to every student id
            sql = "insert into demoedte_Intellify.student (category_id, username, level, registrationno) values (%s, %s, %s, %s)"
            cursor.execute(sql, (school_id, student_id, level, student_id))
            
        # get quizid corresponding to every student id
        sql = "select username, quizid, registrationno from demoedte_Intellify.student natural join quizdb.quiz"
        cursor.execute(sql)
        student_details = cursor.fetchall()
        
        # get all question ids from question tabel
        sql = "select quesid from questions"
        cursor.execute(sql)
        question_ids = cursor.fetchall()
        
        # update history table
        for student in student_details:
            
            username, quizid, reg_no = student['username'], student['quizid'], student['registrationno']
            corrects = len(dict_correct_responses[int(reg_no)]['correct_responses'])
            wrongs = len(dict_incorrect_responses[int(reg_no)]['incorrect_responses'])
            total_score = corrects*4
            skill_1_score = dict_skill_wise_scores[int(reg_no)]['skill_1']
            skill_2_score = dict_skill_wise_scores[int(reg_no)]['skill_2']
            skill_3_score = dict_skill_wise_scores[int(reg_no)]['skill_3']
            skill_4_score = dict_skill_wise_scores[int(reg_no)]['skill_4']
            skill_5_score = dict_skill_wise_scores[int(reg_no)]['skill_5']
            
            status = 1  # as round 1 has been finished
            
            sql = "insert into history(`username`,`quizid`,`score`,`correct`,`wrong`,`status`, `skill_1_score`, `skill_2_score`, `skill_3_score`, `skill_4_score`, `skill_5_score`) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            cursor.execute(sql, (username, quizid, total_score, corrects, wrongs, status, skill_1_score, skill_2_score, skill_3_score, skill_4_score, skill_5_score))
            
            # print('quizid: ', reg_no, quizid)
            
            for q_id in question_ids:
                
                # insert student username and quiz id in user_answer table
                sql_2 = "insert into user_answer(`username`, `quesid`) values(%s, %s)"
                cursor.execute(sql_2, (username, q_id['quesid']))
        
        
        # update user_answer table
        for student in student_details:
            
            reg_no = int(student['registrationno'])
            correct_responses = dict_correct_responses[reg_no]
            
            for i in correct_responses.values():
                
                for q_id in i:
                    sql = 'update user_answer set flag = 1 where username = %s and quesid = %s'
                    cursor.execute(sql, (reg_no, q_id))
        """
        # update question wise difficulty level
        for q_id in question_ids:
            accuracy = question_acc['Points'+str(q_id['quesid'])]
            difficulty_level = 1 - accuracy/100
            sql = "update questions set accuracy = %s, difficulty_level = %s where quesid = %s"
            cursor.execute(sql, (accuracy, difficulty_level, q_id['quesid']))
        """
        
    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()

finally:
    
    connection.close()


# In[ ]:




