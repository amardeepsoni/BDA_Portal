#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import pymysql.cursors
import os
import sys


# In[2]:


def get_data(file_name):
    mydir = os.getcwd()
    os.chdir("..")
    path = os.getcwd() + '/Intellify/uploads/csv/questions/'
    data_csv = pd.read_csv(path + file_name)
    os.chdir(mydir)
    return data_csv


# In[3]:


# Connect to the database
connection = pymysql.connect(host='localhost',
                             user='root',
                             password='',
                             db='quizdb',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)


# In[4]:


option_label = {1:'A', 2:'B', 3:'C', 4:'D'}

def mcq4_passage_questions(data_frame,quizid):
    question_numbers = data_frame['question_number']
    question_texts = data_frame['question_text']
    option1_texts, option2_texts, option3_texts, option4_texts = data_frame['option1'], data_frame['option2'], data_frame['option3'], data_frame['option4']
    passage_texts = data_frame['passage']
    answers_texts = data_frame['answer']
    # return answers_texts
    try:
        with connection.cursor() as cursor:
         
            for i in question_numbers:
                q_text = passage_texts[i-1] + '\n\n' + question_texts[i-1]
                quiz_id = quizid
                sql = 'insert into questions(qnstext, quizid) values (%s, %s)'
                cursor.execute(sql, (q_text, quiz_id))
                
                sql = 'select quesid from questions where qnstext = %s and quizid = %s'
                cursor.execute(sql, (q_text, quiz_id))
                
                ques_id = cursor.fetchall()[0]['quesid']
                
                sql = 'insert into options(option_label, text, quesid) values(%s,  %s, %s)'
                cursor.execute(sql,('A', option1_texts[i-1], ques_id))
                
                sql = 'insert into options(option_label, text, quesid) values(%s,  %s, %s)'
                cursor.execute(sql,('B', option2_texts[i-1], ques_id))
                
                sql = 'insert into options(option_label, text, quesid) values(%s,  %s, %s)'
                cursor.execute(sql,('C', option3_texts[i-1], ques_id))
                
                sql = 'insert into options(option_label, text, quesid) values(%s,  %s, %s)'
                cursor.execute(sql,('D', option4_texts[i-1], ques_id))
                
                # print(type(ques_id), type())
                sql = 'insert into answer(quesid, answer) values(%s, %s)'
                cursor.execute(sql,(ques_id, option_label[answers_texts[i-1]]))
             
        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        
    finally:
    
        connection.close()       


# In[5]:


def mcq4_questions(data_frame,quizid):
    question_numbers = data_frame['question_number']
    question_texts = data_frame['question_text']
    option1_texts, option2_texts, option3_texts, option4_texts = data_frame['option1'], data_frame['option2'], data_frame['option3'], data_frame['option4']
    answers_texts = data_frame['answer']
    
    try:
        with connection.cursor() as cursor:
         
            for i in question_numbers:
                q_text = question_texts[i-1]
                quiz_id = quizid
                sql = 'insert into questions(qnstext, quizid) values (%s, %s)'
                cursor.execute(sql, (q_text, quiz_id))
                
                sql = 'select quesid from questions where qnstext = %s and quizid = %s'
                cursor.execute(sql, (q_text, quiz_id))
                
                ques_id = cursor.fetchall()[0]['quesid']
                
                sql = 'insert into options(option_label, text, quesid) values(%s,  %s, %s)'
                cursor.execute(sql,('A', option1_texts[i-1], ques_id))
                
                sql = 'insert into options(option_label, text, quesid) values(%s,  %s, %s)'
                cursor.execute(sql,('B', option2_texts[i-1], ques_id))
                
                sql = 'insert into options(option_label, text, quesid) values(%s,  %s, %s)'
                cursor.execute(sql,('C', option3_texts[i-1], ques_id))
                
                sql = 'insert into options(option_label, text, quesid) values(%s,  %s, %s)'
                cursor.execute(sql,('D', option4_texts[i-1], ques_id))
                
                # print(type(ques_id), type())
                sql = 'insert into answer(quesid, answer) values(%s, %s)'
                cursor.execute(sql,(ques_id, option_label[answers_texts[i-1]]))
             
        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        
    finally:
    
        connection.close()       


# In[ ]:


def mcq2_questions(data_frame,quizid):
    question_numbers = data_frame['question_number']
    question_texts = data_frame['question_text']
    option1_texts, option2_texts, option3_texts, option4_texts = data_frame['option1'], data_frame['option2'], data_frame['option3'], data_frame['option4']
    answers_texts = data_frame['answer']
    
    try:
        with connection.cursor() as cursor:
         
            for i in question_numbers:
                q_text = question_texts[i-1]
                quiz_id = quizid
                sql = 'insert into questions(qnstext, quizid) values (%s, %s)'
                cursor.execute(sql, (q_text, quiz_id))
                
                sql = 'select quesid from questions where qnstext = %s and quizid = %s'
                cursor.execute(sql, (q_text, quiz_id))
                
                ques_id = cursor.fetchall()[0]['quesid']
                
                sql = 'insert into options(option_label, text, quesid) values(%s,  %s, %s)'
                cursor.execute(sql,('A', option1_texts[i-1], ques_id))
                
                sql = 'insert into options(option_label, text, quesid) values(%s,  %s, %s)'
                cursor.execute(sql,('B', option2_texts[i-1], ques_id))
                
                # print(type(ques_id), type())
                sql = 'insert into answer(quesid, answer) values(%s, %s)'
                cursor.execute(sql,(ques_id, option_label[answers_texts[i-1]]))
             
        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        
    finally:
    
        connection.close()       


# In[6]:


def integer_questions(data_frame,quizid):
    question_numbers = data_frame['question_number']
    question_texts = data_frame['question_text']
    # option1_texts, option2_texts, option3_texts, option4_texts = data_frame['option1'], data_frame['option2'], data_frame['option3'], data_frame['option4']
    answers_texts = data_frame['answer']

    try:
        with connection.cursor() as cursor:
         
            for i in question_numbers:
                q_text = question_texts[i-1]
                quiz_id = quizid
                sql = 'insert into questions(qnstext, quizid) values (%s, %s)'
                cursor.execute(sql, (q_text, quiz_id))
                
                sql = 'select quesid from questions where qnstext = %s and quizid = %s'
                cursor.execute(sql, (q_text, quiz_id))
                
                ques_id = cursor.fetchall()[0]['quesid']
                
                # print(type(ques_id), type())
                sql = 'insert into answer(quesid, answer) values(%s, %s)'
                cursor.execute(sql,(ques_id, str(answers_texts[i-1])))
             
        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        
    finally:
    
        connection.close()       


# In[8]:


if __name__ == '__main__':
    
    file_name, question_type, quizid = sys.argv[1], sys.argv[2], sys.argv[3]
    data_frame = get_data(file_name)
    
    if question_type == 'mcq2':
        mcq2_questions(data_frame,quizid)
    elif question_type == 'mcq4':
        mcq4_questions(data_frame,quizid)
    elif question_type == 'int':
        integer_questions(data_frame,quizid)


# In[ ]:




