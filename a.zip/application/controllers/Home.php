<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index() {

		$this->load->model('model_setting');  
        $this->load->model('model_page');

		$data['page_title']=webdata()->page_title;


		$data['meta_keyword']=webdata()->meta_keyword;


		$data['meta_description']=webdata()->meta_description;

		$data['action']=base_url('register');
		
		
		
$this->load->model('model_testimonials');

$data['testimonials']= array();	
    	$results = $this->model_testimonials->gettestimonials(0);
		if ($results) {  
			foreach($results as $val){
				if($val->image) {	
					$image = UPLOADFILE.$val->image;
				}

				else {
					$image = UPLOADFILE.'no_image.jpg';
				}
				$data['testimonials'][] = array(
				    'id' => $val->id,	
					'name' => $val->name,	
					'home' => $val->home,
					'designation' => $val->designation,							
					'description' => $val->description,									
                  
				    'image' => $image

				);
			}
		}




$this->load->model('model_projects');

$data['homeprojects']= array();	
    	$results = $this->model_projects->gethomeprojects(0);
		if ($results) {  
			foreach($results as $val){
				
				if($val->icon) {	
				$icon = UPLOADFILE.$val->icon;
				}

				else {
					$icon = UPLOADFILE.'no_image.jpg';
				}
				
							
				$data['homeprojects'][] = array(
				    'id' => $val->id,	
					'name' => $val->name,	
					'home' => $val->home,				
					'shortdescription' => $val->shortdescription,							
					'icon' => $icon

				);
			}
		}












		$this->load->view('header',$data);
		$this->load->view('home',$data);
		$this->load->view('footer');


	}



}