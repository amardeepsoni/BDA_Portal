<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UploadController extends CI_Controller {

    function __construct()
    {
        parent::__construct();

        exec('pip3 install pandas');
    }

    private function is_process_running($PID){
        exec("ps $PID", $ProcessState);
        return(count($ProcessState) >= 2);
    }
    private function runScript($csvName) {
        //$command = escapeshellcmd("");
       // $pid = exec("nohup $command 2> /dev/null & echo $! 2>&1",$output,$return_var);

         $o = shell_exec('/usr/bin/python3 scripts/result_analysis.py '.$csvName.' 2>&1');
        print_r($o) ;
//        print_r($output);
//        print_r($return_var);
//
//        while($this->is_process_running($pid))
//        {
//            echo(" . ");
//            ob_flush(); flush();
//            sleep(1);
//        }
//        echo "Complete";
    }

    private function runQuesScript($csvName , $qtype , $quizid) {
        //$command = escapeshellcmd("");
        // $pid = exec("nohup $command 2> /dev/null & echo $! 2>&1",$output,$return_var);
       // echo $quizid;
        //echo '/usr/bin/python3 scripts/question_upload.py '.$csvName.' '.$qtype.' '.$quizid.' 2>&1';
        $o = shell_exec('/usr/bin/python3 scripts/question_upload.py '.$csvName.' '.$qtype.' '.$quizid.' 2>&1');
        //print_r($o) ;
//        print_r($output);
//        print_r($return_var);
//
//        while($this->is_process_running($pid))
//        {
//            echo(" . ");
//            ob_flush(); flush();
//            sleep(1);
//        }
//        echo "Complete";
    }

    public function index()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect(adminpath.'/login');
        }
        $data['error'] = '';
        $data['success'] = '';
        $this->load->view(adminpath.'/header');
        $this->load->view(adminpath.'/uploadCSV',$data);
        $this->load->view(adminpath.'/footer');
    }

    public function uploadData() {
        $config = array(
            'upload_path' => "./uploads/csv",
            'allowed_types' => "csv",
            'overwrite' => TRUE,
            'max_size' => "20480000",
        );
        $this->load->library('upload',$config);
        if($this->upload->do_upload('user_file'))
        {   $data['error'] = '';
            $data['success'] = "Uploaded Successfully";
            $file_data = $this->upload->data();
            $this->runScript($file_data['file_name']);
            //$this->load->view(adminpath.'/uploadCSV',$data);
        }
        else
        {
            $data['success'] = '';
            $data['error'] = $this->upload->display_errors();
            $this->load->view(adminpath.'/uploadCSV', $data);
        }

    }

    public function uploadQuesData() {
        $config = array(
            'upload_path' => "./uploads/csv/questions",
            'allowed_types' => "csv",
            'overwrite' => TRUE,
            'max_size' => "20480000",
        );
        $this->load->library('upload',$config);
        if($this->upload->do_upload('user_file'))
        {   $file_data = $this->upload->data();
           // print_r($this->input->post('quizid'));
            $this->runQuesScript($file_data['file_name'], $this->input->post('qtype'), $this->input->post('quizid'));
           // redirect(adminpath.'/AllExams');
            $questionData = array(
                'quizid' => $this->input->post('quizid'),
                'mcq2' => 0,
                'mcq4' => 0,
                'integer' => 0,
                'success' => "",
                'error' => "",
                'action' => base_url() . adminpath . '/AddExam/submitQuestions'
            );
            $this->load->view(adminpath . '/header');
            $this->load->view(adminpath . '/addExamQuestions.php', $questionData);
            $this->load->view(adminpath . '/footer');
        }
        else
        {
            $data['success'] = '';
            $data['error'] = $this->upload->display_errors();
            //Make error page to display all errors
            //$this->load->view(adminpath.'/addExamQuestions', $data);
        }

    }
}