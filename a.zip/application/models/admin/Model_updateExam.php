<?php
class Model_updateExam extends CI_Model
{

    function __construct()
    {
        parent::__construct();
        $this->quizdb = $this->load->database('quizdb', TRUE);
    }

    public function  enableExam($quizid) {
        $this->quizdb->where('quizid',$quizid)->update('quiz',array('status' => 1));
        return $this->quizdb->affected_rows();
    }

    public function  disableExam($quizid) {
        $this->quizdb->where('quizid',$quizid)->update('quiz',array('status' => 0));
        return $this->quizdb->affected_rows();
    }

    public function  removeExam($quizid) {
        $query = $this->quizdb->select('*')->from('questions')->where('quizid',$quizid)->get();
        $questions = $query->result();
        foreach ($questions as $ques) {
            if($this->quizdb->where('quesid',$ques->quesid)->delete('user_answer') and $this->quizdb->where('quesid',$ques->quesid)->delete('options') and $this->quizdb->where('quesid', $ques->quesid)->delete('answer') )
                continue;
            else
                return false;
        }
        if($this->quizdb->where('quizid',$quizid)->delete('questions'))
            return $this->quizdb->where('quizid',$quizid)->delete('quiz');
        else
            return false;
    }

    public function getExamByID($quizid) {
        $query = $this->quizdb->select('*')->from('quiz')->where('quizid',$quizid)->limit(1)->get();
        return $query->row();
    }

    public function getQuestionsByQuizID($quizid) {
        $query = $this->quizdb->select('*')->from('questions')->where('quizid',$quizid)->get();
        return $query->result();

    }

    public function getOptionsByQuestionID($quesid) {
        $query = $this->quizdb->select('*')->from('options')->where('quesid',$quesid)->get();
        return $query->result();
    }

    public function deleteQuestionByID($quesid) {
        if($this->quizdb->where('quesid',$quesid)->delete('user_answer') and $this->quizdb->where('quesid',$quesid)->delete('options') and $this->quizdb->where('quesid', $quesid)->delete('answer') )
            return $this->quizdb->where('quesid',$quesid)->delete('questions');
        else
            return false;
    }

}