
<div id="page-content-wrapper">
<a href="#menu-toggle" class="menuopener" id="menu-toggle"><i class="fa fa-bars"></i></a>
<div class=" parallax section looking-photo nopadbot" data-stellar-background-ratio="0.5" style="background-image:url('<?php echo base_url();?>schoolassest/upload/demo_02.jpg');">
  <div class="page-title section nobg">
    <div class="container-fluid">
      <div class="clearfix">
        <div class="title-area pull-left">
          <h2>Student account <small></small></h2>
        </div>
        <!-- /.pull-right -->
        <div class="pull-right hidden-xs">
          <div class="bread">
            <ol class="breadcrumb">
              <li><a href="<?php echo base_url();?>schoolassest">Home</a></li>
              <li class="active">Student account</li>
            </ol>
          </div>
          <!-- end bread --> 
        </div>
        <!-- /.pull-right --> 
      </div>
      <!-- end clearfix --> 
    </div>
  </div>
  <!-- end page-title --> 
</div>
<div class="section">
  <div class="container-fluid">
    <?php if ($this->session->flashdata('loginnotify')) { ?>
    <div class="alert alert-danger">
      <?= $this->session->flashdata('loginnotify') ?>
    </div>
    <?php } ?>
    <h3>Welcome to <?php echo $studentinfo->firstname; ?> <?php echo $studentinfo->lastname; ?></h3>
    <div class="cnt-block">
      <div class="row">
      
      
      <?php if($studentinfo->email){?>
        <div class="form-group col-lg-6">
          <label><b>Email:</b></label>
          <?php echo $studentinfo->email; ?> </div>
          <?php }?>
          
          
        <div class="form-group col-lg-6">
          <label><b>Mobile:</b></label>
          <?php echo $studentinfo->mobile; ?> </div>
          
             <div class="form-group col-lg-6">
          <label><b>Registration No:</b></label>
          <?php echo $studentinfo->registrationno; ?> </div>
          
        <div class="form-group col-lg-6">
          <label><b>Date of Birth:</b></label>
          <?php echo $studentinfo->dob; ?> </div>
          
           <?php if($studentinfo->gender){?>
        <div class="form-group col-lg-6">
          <label><b>Gender</b></label>
          <?php echo $studentinfo->gender; ?> </div>
          
            <?php }?>
           <?php if($studentinfo->address){?>
        <div class="form-group col-lg-12">
          <label><b>Address:</b></label>
          <br>
          <?php echo $studentinfo->address; ?> </div><?php }?>
        
      </div>
    </div>
    <br />
    
    <!-- end row --> 
  </div>
  <!-- end container --> 
</div>
<!-- end section --> 

