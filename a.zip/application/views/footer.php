<footer class="footer">
  <!-- Start Footer Top -->
  
  <div class="container">
    <div class="row row1">
      <div class="col-sm-9 clearfix">
        <div class="foot-nav">
          <h3>ISCO</h3>
          <ul>
            <li><a href="#">Register your School </a></li>
            <li><a href="#">ISCO 2018 Guidelines </a></li>
            <li><a href="#">ISCO 2017 </a></li>
          </ul>
        </div>
        <div class="foot-nav">
          <h3>Projects</h3>
          <ul>
            <li><a href="#">School Redesign</a></li>
            <li><a href="#">Solve App</a></li>
            <li><a href="#">Student Portalt</a></li>
          </ul>
        </div>
        <div class="foot-nav">
          <h3>Why Intellify</h3>
          <ul>
            <li><a href="#">Blogs</a></li>
            <li><a href="#">Reserach</a></li>
            <li><a href="#">CV</a></li>
          </ul>
        </div>
        <div class="foot-nav">
          <h3>Partners</h3>
          <ul>
            <li><a href="#">Delhi Government</a></li>
            <li><a href="#">Teach for India</a></li>
            <li><a href="#">Interactive Practice</a></li>
            <li><a href="#">NSS IIT Delhi</a></li>
          </ul>
        </div>
      </div>
      <div class="col-sm-3">
        <div class="footer-logo hidden-xs"><a href="index-2.html"><img  src="<?php echo base_url();?>images/logo-new.png" class="img-responsive" alt=""></a></div>
        <p>© 2018 <span>Intellify</span>. All rights reserved</p>
        <ul class="terms clearfix">
          <li><a href="#">TERMS OF USE</a></li>
          <li><a href="#">PRIVACY POLICY</a></li>
          <li><a href="#">SITEMAP</a></li>
        </ul>
      </div>
    </div>
  </div>
  <!-- End Footer Top --> 
  <!-- Start Footer Bottom -->
  <div class="bottom">
    <div class="container">
      <div class="row">
        <div class="col-sm-4">
          <div class="connect-us">
            <h3>Connect with Us</h3>
            <ul class="follow-us clearfix">
              <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
              <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
              <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
              <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
              <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
            </ul>
          </div>
        </div>
        <div class="col-sm-4">
          <div class="subscribe">
            <h3>Subscribe  with Us</h3>
            <!-- Begin MailChimp Signup Form -->
            <div id="mc_embed_signup">
              <form action="http://protechtheme.us16.list-manage.com/subscribe/post?u=cd5f66d2922f9e808f57e7d42&amp;id=ec6767feee" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                <div id="mc_embed_signup_scroll">
                <input type="email" value="" name="EMAIL" class="email" id="mce-EMAIL" placeholder="enter your email address" required>
                <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                <div style="position: absolute; left: -5000px;" aria-hidden="true">
                  <input type="text" name="" tabindex="-1" value="">
                </div>
                <div class="clear">
                <button type="button"   id="" class="button">
                </div>
                </div>
              </form>
            </div>
            <!--End mc_embed_signup--> 
          </div>
        </div>
        <div class="col-sm-4">
          <div class="instagram">
            <h3>@INSTAGRAM</h3>
            <ul class="clearfix">
              <li><a href="#">
                <figure><img  src="<?php echo base_url();?>images/insta-img1.jpg" class="img-responsive" alt=""></figure>
                </a></li>
              <li><a href="#">
                <figure><img  src="<?php echo base_url();?>images/insta-img2.jpg" class="img-responsive" alt=""></figure>
                </a></li>
              <li><a href="#">
                <figure><img  src="<?php echo base_url();?>images/insta-img3.jpg" class="img-responsive" alt=""></figure>
                </a></li>
              <li><a href="#">
                <figure><img  src="<?php echo base_url();?>images/insta-img4.jpg" class="img-responsive" alt=""></figure>
                </a></li>
              <li><a href="#">
                <figure><img src="<?php echo base_url();?>images/insta-img5.jpg" class="img-responsive" alt=""></figure>
                </a></li>
              <li><a href="#">
                <figure><img  src="<?php echo base_url();?>images/insta-img6.jpg" class="img-responsive" alt=""></figure>
                </a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- End Footer Bottom -->
  </footer>
  <!-- End Footer --> 
  
  <!-- Scroll to top --> 
  <a href="#" class="scroll-top"><i class="fa fa-chevron-up" aria-hidden="true"></i></a> 
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-1.12.2.js"></script> 
  <script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script> 
  <script src="<?php echo base_url();?>assets/js/common.js"></script> 
  <script type="text/javascript" src="<?php echo base_url('assets/js/valiation/jquery.validate.min.js'); ?>"></script> 
  <script type="text/javascript" src="<?php echo base_url('assets/js/valiation/formvalidation.js'); ?>"></script> 
  <script type="text/javascript" src="<?php echo base_url('assets/js/valiation/additional-methods.min.js'); ?>"></script> 
  
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
  <!-- Bootsrap JS --> 
  
  <!-- Select2 JS --> 
  <script src="<?php echo base_url();?>assets/select2/js/select2.min.js"></script> 
  <!-- Match Height JS --> 
  <script src="<?php echo base_url();?>assets/matchHeight/js/matchHeight-min.js"></script> 
  <!-- Bxslider JS --> 
  <script src="<?php echo base_url();?>assets/bxslider/js/bxslider.min.js"></script> 
  <!-- Waypoints JS --> 
  <script src="<?php echo base_url();?>assets/waypoints/js/waypoints.min.js"></script> 
  <!-- Counter Up JS --> 
  <script src="<?php echo base_url();?>assets/counterup/js/counterup.min.js"></script> 
  <!-- Magnific Popup JS --> 
  <script src="<?php echo base_url();?>assets/magnific-popup/js/magnific-popup.min.js"></script> 
  <!-- Owl Carousal JS --> 
  <script src="<?php echo base_url();?>assets/owl-carousel/js/owl.carousel.min.js"></script> 
  <!-- Modernizr JS --> 
  <script src="<?php echo base_url();?>js/modernizr.custom.js"></script> 
  <!-- Custom JS --> 
  <script src="<?php echo base_url();?>js/custom.js"></script>
  </body></html>