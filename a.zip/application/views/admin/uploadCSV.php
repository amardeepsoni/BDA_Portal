<div class="container body">
    <div class="main_container">
        <?php $this->load->view(adminpath.'/sidebar') ?>
        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">
                <div class="clearfix"></div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <div class="" style="text-align: center;">
                                    <?php echo $error ?>
                                    <?php echo $success ?>
                                    <?php echo form_open_multipart(base_url().adminpath.'/UploadController/uploadData');?>
                                    <?php echo "<input type='file' name='user_file' size='20' align='right'/>"; ?>
                                    <?php echo "<button class='my-button' type='submit'>Submit</button> ";?>
                                    <?php echo "</form>"?>
                                </div>
                            </div>
                            <div class="x_content">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

    </div>
</div>
