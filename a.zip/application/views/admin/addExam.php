
<div class="container body">
    <div class="main_container">
        <?php $this->load->view(adminpath.'/sidebar') ?>
        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">
                <div class="clearfix"></div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2><?php echo $heading; ?><small>
                                        <ul class="nav navbar-right panel_toolbox">
                                            <?php
                                            if(isset($breadcrumbs)) {
                                                foreach($breadcrumbs as $rw) {
                                                    echo "<li><a href='".$rw['href']."'>".$rw['text']."</a></li>";
                                                }
                                            }

                                            ?>
                                        </ul>
                                    </small></h2>
                                <div class="container col-12 col-sm-6 col-md-6 site-form" id="admin-add-exam">
            <form id="my-form" action="<?php echo $action ?>" method="post">
                <div class="form-group"><label  for="quiztitle">Quiz Title</label><input class="form-control" type="text" name="title" placeholder="Enter Quiz Title" autofocus id="title" /></div>
                <div class="form-group"><label  for="mcq2">MCQ-2 Type Questions</label><input class="form-control" type="number" value=0 name="mcq2" placeholder="Enter number of MCQ (2 option) type questions" id="mcq2" /></div>
                <div class="form-group"><label  for="mcq4">MCQ-4 Type Questions</label><input class="form-control" type="number" value=0 name="mcq4" placeholder="Enter number of MCQ (4 option) type questions" id="mcq4" /></div>
                <div class="form-group"><label  for="integer">Integer Type Questions</label><input class="form-control" type="number" value=0 name="integer" placeholder="Enter number of integer type questions" id="integer" /></div>
                
                <div class="form-group"><label  for="correct_marks">Marks for correct answer</label><input class="form-control" type="number" name="correct" required placeholder="Enter marks to be alloted for correct answer" id="correct" /></div>
                <div class="form-group"><label  for="incorrect_marks">Marks for incorrect answer</label><input class="form-control" type="number" name="wrong" required placeholder="Enter marks to be alloted for incorrect answer" id="wrong" /></div>
                
                <div class="form-group"><label  for="duration">Time Duration (Minutes)</label><input class="form-control" type="number" name="time" required placeholder="Enter time duration for the exam" id="time" /></div>
                <div class="form-group"><label  for="examlevel">Quiz Level</label><input class="form-control" type="number" name="level" required placeholder="Enter exam level" id="level" /></div>
                <div class="form-group"><label  for="skillname">Skill Name</label><input class="form-control" type="text" name="skill_name" required placeholder="Enter skill name" id="skill_name" /></div>
                <div class="form-group"><label  for="belongsto">Quiz belongs to</label><input class="form-control" type="text" name="belongs_to" required placeholder="Enter round number to which the exam belongs  0 for round 1, 1 for round 2" id="belongs_to" /></div>
                <button class="my-button" type="submit"><b>Submit</b></button>
            </form>
        </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

    </div>
</div>
