<h1><?php echo $username?></h1>

<?php
foreach ($skills as $skill) {
   echo "<div><a href='#'>$skill->skill_name</a></div>";
}

?>
