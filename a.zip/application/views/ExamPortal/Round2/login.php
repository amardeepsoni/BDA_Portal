<form name="loginform"  method="post" action="<?php echo $action; ?>" id="loginform">
                    <h3>Login</h3>
                    <hr>
                    <div class="row">
                        <div class="form-group col-lg-12">
                            <label>Username</label>
                            <input name="username" required="" value="<?php if(isset($_POST['username'])){ echo $_POST['username']; } ?>" type="text" id="username" class="form-control">
                        </div>
                        <div class="form-group col-lg-12">
                            <label>Password</label>
                            <input name="password" required=""  value="" type="password" id="password" class="form-control">
                        </div>
                        <div class="col-sm-12">
                            <button type="submit" class="btn btn-primary">Login</button>
                        </div>
                    </div>
</form>